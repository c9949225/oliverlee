RTL
* Mirrors Blueprint, so it can be used with Right-to-Left languages.

By Ran Yaniv Hartstein, ranh.co.il

Usage
----------------------------------------------------------------

1) Add this plugin to lib/settings.yml.
   See compress.rb for instructions.
	 
