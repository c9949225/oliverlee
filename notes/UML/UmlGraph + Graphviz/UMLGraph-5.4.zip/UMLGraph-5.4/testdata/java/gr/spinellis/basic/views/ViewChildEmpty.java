package gr.spinellis.basic.views;

/**
 * @view
 */
public class ViewChildEmpty extends ViewAbstract {
}
