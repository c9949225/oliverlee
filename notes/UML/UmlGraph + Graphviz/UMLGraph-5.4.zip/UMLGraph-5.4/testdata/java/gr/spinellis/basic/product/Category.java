package gr.spinellis.basic.product;
import java.util.*;

/**
 * @depend - - - java.util.List
 */
public class Category {

    public String name;
    List products;
}
