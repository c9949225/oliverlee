// $Id: extends.java,v 1.1 2005/11/23 22:18:45 dds Exp $

class Base {}
class Test2<B extends a.b.Base> {}
