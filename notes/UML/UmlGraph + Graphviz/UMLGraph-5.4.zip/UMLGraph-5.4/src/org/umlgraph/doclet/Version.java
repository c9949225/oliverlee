/* Automatically generated file */
package org.umlgraph.doclet;
class Version { public static String VERSION = "5.4";}
	